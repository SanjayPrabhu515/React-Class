import React from 'react';

const ReportGeneration = () => {
  return (
    <div className="report-generation">
      <h1>Report Generation</h1>
      <p>Generate and view reports related to sales, inventory, and more.</p>
    </div>
  );
};

export default ReportGeneration;
