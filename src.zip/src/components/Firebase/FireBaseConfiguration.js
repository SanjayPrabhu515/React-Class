import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getAnalytics } from "firebase/analytics";


const firebaseConfig = {
  apiKey: "AIzaSyBOsADKU9iXzz5PtLILuNpbQsPrh_GDmpc",
  authDomain: "reactproject-9a510.firebaseapp.com",
  projectId: "reactproject-9a510",
  storageBucket: "reactproject-9a510.appspot.com",
  messagingSenderId: "680084898969",
  appId: "1:680084898969:web:ceed127a0933119c87a408",
  measurementId: "G-8HC0CP4TXE"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
const analytics = getAnalytics(app);